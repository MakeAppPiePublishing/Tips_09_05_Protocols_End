//
//  A Demo for iOS Development Tips Weekly
//  by Steven Lipton (C)2020, All rights reserved
// Check out the video series on LinkedIn learning at https://linkedin-learning.pxf.io/YxZgj
//  For code go to http://bit.ly/AppPieGithub

//:#Protocol Demo
//: Learn what a protocol is and what you can do with them. 
protocol Pizza{
    var length:Double{ get }
    var width:Double { get set }
    var toppings:[String]{get set}
    func area()->Double
    init(length:Double,width:Double)
}

extension Pizza{
    func toppingString()->String{
        var d = ""
        for topping in toppings{
            d += topping + " "
        }
        return d
    }
}

class RectanglePizza:Pizza{
    var length: Double
    
    var width: Double
    
    var toppings: [String]
    
    func area() -> Double {
        return length * width
    }
    
    required init(length: Double, width: Double) {
        self.length = length
        self.width = width
        toppings = ["Cheese"]
    }
    

}


struct RoundPizza:Pizza{
    var length: Double{
        return width
    }
    
    var width: Double
    
    var toppings: [String] = ["Pepperoni"]
    
    func area() -> Double {
        let z = width / 2.0
        return Double.pi * z * z
    }
    
    init(length: Double, width: Double) {
        self.width = width
    }
    
    init(diameter:Double){
        self.width = diameter
    }
    
    
}

//: Test Area
let a = RectanglePizza(length: 15, width: 12)
let b = RoundPizza(diameter:10)
b.area()
a.area()
a.toppingString()
